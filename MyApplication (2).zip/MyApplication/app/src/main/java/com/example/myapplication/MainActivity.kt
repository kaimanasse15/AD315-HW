package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    private lateinit var counterTextView: TextView
    private lateinit var incrementButton: Button
    private lateinit var decrementButton: Button
    private lateinit var resetButton: Button

    private var counter = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        counterTextView = findViewById(R.id.counterTextView)
        incrementButton = findViewById(R.id.incrementButton)
        decrementButton = findViewById(R.id.decrementButton)
        resetButton = findViewById(R.id.resetButton)

        // Increment button click listener
        incrementButton.setOnClickListener {
            val previousValue = counter
            counter++
            val nextValue = counter
            counterTextView.text = counter.toString()
            showToast("Increment: $previousValue -> $nextValue")
        }

        // Decrement button click listener
        decrementButton.setOnClickListener {
            val previousValue = counter
            counter--
            val nextValue = counter
            counterTextView.text = counter.toString()
            showToast("Decrement: $previousValue -> $nextValue")
        }

        // Reset button click listener
        resetButton.setOnClickListener {
            val previousValue = counter
            counter = 0
            val nextValue = counter
            counterTextView.text = counter.toString()
            showToast("Reset: $previousValue -> $nextValue")
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}

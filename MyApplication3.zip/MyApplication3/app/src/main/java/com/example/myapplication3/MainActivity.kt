import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.example.myapplication3.R

class MainActivity : AppCompatActivity() {

    private lateinit var incrementButton: Button
    private lateinit var decrementButton: Button
    private lateinit var resetButton: Button
    private lateinit var textView: TextView

    private var value: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        incrementButton = findViewById(R.id.increment_button)
        decrementButton = findViewById(R.id.decrement_button)
        resetButton = findViewById(R.id.reset_button)
        textView = findViewById(R.id.text_view)

        textView.text = value.toString()

        incrementButton.setOnClickListener {
            val prevValue = value
            value++
            textView.text = value.toString()
            val message = "Increment: $prevValue -> $value"
            showToast(message)
        }

        decrementButton.setOnClickListener {
            val prevValue = value
            value--
            textView.text = value.toString()
            val message = "Decrement: $prevValue -> $value"
            showToast(message)
        }

        resetButton.setOnClickListener {
            val prevValue = value
            value = 0
            textView.text = value.toString()
            val message = "Reset: $prevValue -> $value"
            showToast(message)
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}

package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    private lateinit var imageView: ImageView
    private lateinit var buttonTouch: Button
    private lateinit var buttonFood: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imageView = findViewById(R.id.imageView2)
        buttonTouch = findViewById(R.id.buttonTouch)
        buttonFood = findViewById(R.id.buttonFood)

        buttonTouch.setOnClickListener {
            imageView.setImageResource(R.drawable.angryshiba)
            Toast.makeText(this, "Don't touch me!", Toast.LENGTH_SHORT).show()
        }

        buttonFood.setOnClickListener {
            imageView.setImageResource(R.drawable.image3)
            Toast.makeText(this, "Thanks for the food!", Toast.LENGTH_SHORT).show()
        }
    }
}


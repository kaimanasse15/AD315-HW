// MainActivity.kt
package com.example.myapplication

import android.app.Application
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.databinding.ObservableField
import androidx.lifecycle.ViewModel
import com.example.myapplication.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: MyViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        viewModel = MyViewModel()
        binding.viewModel = viewModel
    }
}

class MyViewModel : ViewModel() {

    val value = ObservableField<Int>(0)

    fun incrementValue() {
        val previousValue = value.get() ?: 0
        value.set(previousValue + 1)
        val message = "Increment: $previousValue -> ${value.get()}"
        showToast(message)
    }

    fun decrementValue() {
        val previousValue = value.get() ?: 0
        value.set(previousValue - 1)
        val message = "Decrement: $previousValue -> ${value.get()}"
        showToast(message)
    }

    fun resetValue() {
        val previousValue = value.get() ?: 0
        value.set(0)
        val message = "Reset: $previousValue -> 0"
        showToast(message)
    }

    private fun showToast(message: String) {
        Toast.makeText(MyApplication.instance.applicationContext, message, Toast.LENGTH_SHORT).show()
    }
}

class MyApplication : Application() {

    companion object {
        lateinit var instance: MyApplication
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }
}

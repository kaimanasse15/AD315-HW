package com.example.myapplication2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private val movieList = listOf(
        Movie("The Godfather", 1972, "The aging patriarch of an organized crime dynasty transfers control of his clandestine empire to his reluctant son."),
        Movie("The Shawshank Redemption", 1994, "Two imprisoned men bond over a number of years, finding solace and eventual redemption through acts of common decency."),
        Movie("The Dark Knight", 2008, "When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests of his ability to fight injustice.")
    )

    private val placeList = listOf(
        Place("Paris, France", "Europe"),
        Place("Bali, Indonesia", "Asia"),
        Place("Barcelona, Spain", "Europe")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val movieRecyclerView: RecyclerView = findViewById(R.id.movie_list)
        movieRecyclerView.layoutManager = LinearLayoutManager(this)

        val placeRecyclerView: RecyclerView = findViewById(R.id.place_list)
        placeRecyclerView.layoutManager = LinearLayoutManager(this)

        val movieAdapter = MovieAdapter(movieList)
        val placeAdapter = PlaceAdapter(placeList)

        movieRecyclerView.adapter = movieAdapter
        placeRecyclerView.adapter = placeAdapter
    }

    data class Movie(val title: String, val year: Int, val plot: String)

    data class Place(val name: String, val continent: String)

    class MovieAdapter(private val movieList: List<Movie>) :
        RecyclerView.Adapter<MovieAdapter.MovieViewHolder>() {

        class MovieViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            val itemTitle: TextView = itemView.findViewById(R.id.item_title)
            val itemYear: TextView = itemView.findViewById(R.id.item_year)
            val itemPlot: TextView = itemView.findViewById(R.id.item_plot)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MovieViewHolder {
            val layout = LayoutInflater.from(parent.context).inflate(R.layout.item_movie,
                parent, false)
            return MovieViewHolder(layout)
        }

        override fun onBindViewHolder(holder: MovieViewHolder, position: Int) {
            val movie = movieList[position]
            holder.itemTitle.text = movie.title
            holder.itemYear.text = movie.year.toString()
            holder.itemPlot.text = movie.plot
        }

        override fun getItemCount() = movieList.size
    }

    class PlaceAdapter(private val placeList: List<Place>) :
        RecyclerView.Adapter<PlaceAdapter.PlaceViewHolder>() {

        class PlaceViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            val itemName: TextView = itemView.findViewById(R.id.item_name)
            val itemContinent: TextView = itemView.findViewById(R.id.item_continent)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PlaceViewHolder {
            val layout = LayoutInflater.from(parent.context).inflate(R.layout.item_place,
                parent, false)
            return PlaceViewHolder(layout)
        }

        override fun onBindViewHolder(holder: PlaceViewHolder, position: Int) {
            val place = placeList[position]
            holder.itemName.text = place.name
            holder.itemContinent.text = place.continent
        }

        override fun getItemCount() = placeList.size
    }
}
